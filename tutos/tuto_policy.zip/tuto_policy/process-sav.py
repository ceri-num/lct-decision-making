#!env python3
"""
First 421 player 
"""
import json

logFile= "421-log-sav.csv"
policyFile= "421-pi.json"

data= {}

def searchAction( actionDico ):
    bestAction= ""
    bestValue= 0
    for a in actionDico :
        value= sum( actionDico[a] ) / len(actionDico[a])
        if bestAction == "" or value > bestValue :
            bestAction= a
            bestValue= value
    return bestAction

def stat( stateDico, action ):
    counter= len( stateDico[action] )
    return sum( stateDico[action] )/counter, counter

# Load data:
logFile= open( logFile, "r")
for line in logFile :
    state, action, value= tuple( line.split(', ') )
    value= float(value)
    if state not in data :
        data[state]= {action: [value]}
    elif action not in data[state]:
        data[state][action]= [value]
    else :
        data[state][action].append( value )
logFile.close()

for state in data :
    for action in data[state] :
        average, size= stat( data[state], action )
        #print( f"{state}, {action}, {average}, {size}" )

# Build policy:
policy= {}
for state in data :
    policy[state]= searchAction( data[state] )

# Record it:
policyFile= open(policyFile, "w")
json.dump(policy, policyFile, sort_keys=True, indent=2 )
policyFile.close()

#print( '\n'.join( [ f"{state} -> {policy[state]}" for state in policy] ) )
