#!env python3
"""
First 421 player 
"""
import json

import sys
sys.path.insert( 1, __file__.split('tutos')[0] )

# Local HackaGame:
import hackagames.hackapy as hg

def log( aString ):
    #print( aString )
    pass

class Bot() :

    def __init__(self, policyFilePath= "421-pi.json"):
        super().__init__()
        policyFile= open(policyFilePath)
        self.policy= json.load( policyFile )
        policyFile.close()

    # State Machine :
    def state(self):
        return '-'.join([ str(d) for d in self.dices ])+f"h{str(self.horizon)}"
    
    # Player interface :
    def wakeUp(self, playerId, numberOfPlayers, gameConf):
        self._trace= []
        log( f'---\nwake-up player-{playerId} ({numberOfPlayers} players)')
        log( gameConf )

    def perceive(self, gameState):
        elements= gameState.children()
        self.horizon= elements[0].flag(1)
        self.dices= elements[1].flags()
        log( "< "+self.state() )

    def decide(self):
        action= self.policy[ self.state() ]
        log( "> "+ action )
        return action

    def sleep(self, result):
        log( "End: "+ str(result) )
        pass
