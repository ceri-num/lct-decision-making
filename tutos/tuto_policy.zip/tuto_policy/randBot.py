#!env python3
"""
First 421 player 
"""
import random

import sys
sys.path.insert( 1, __file__.split('tutos')[0] )

# Local HackaGame:
import hackagames.hackapy as hg

def log( aString ):
    #print( aString )
    pass

class Bot() :

    def __init__( self, logPath="421-log-sav.csv" ):
        self._logPath= logPath

    # State Machine :
    def state(self):
        return '-'.join([ str(d) for d in self.dices ])+f"h{str(self.horizon)}"
    
    # Player interface :
    def wakeUp(self, playerId, numberOfPlayers, gameConf):
        self._trace= []
        log( f'---\nwake-up player-{playerId} ({numberOfPlayers} players)')
        log( gameConf )
        self._actions= ['keep-keep-keep', 'keep-keep-roll', 'keep-roll-keep', 'keep-roll-roll',
            'roll-keep-keep', 'roll-keep-roll', 'roll-roll-keep', 'roll-roll-roll' ]

    def perceive(self, gameState):
        elements= gameState.children()
        self.horizon= elements[0].flag(1)
        self.dices= elements[1].flags()
        log( f'H: {self.horizon} DICES: {self.dices}' )

    def decide(self):
        action= random.choice( self._actions )
        self._trace.append( {
            'state': self.state(),
            'action': action
        } )
        return action

    def sleep(self, result):
        logFile= open( self._logPath, "a" )
        for t in self._trace :
            logFile.write( f"{t['state']}, {t['action']}, {result}\n" )
        logFile.close()

# script :
if __name__ == '__main__' :
    player= AutonomousPlayer()
    results= player.takeASeat()
    print( f"\n## Statistics:\n\tAverage: { float(sum(results))/len(results) }" )
